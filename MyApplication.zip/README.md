# Budgeat
## Tools
1. Android Studio 
2. SQLite Expert Personal
## Instruction
1. Once you download the file, use android developer to open the directory. It is going to take some time for Android to build the project.
2. Download the csv plugins Android developer.
3. Restart the Android after download csv plugins in Android Developer.
4. Run the code.
